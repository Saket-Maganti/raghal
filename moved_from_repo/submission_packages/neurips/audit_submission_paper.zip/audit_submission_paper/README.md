# Audit Submission Paper

Double-blind blended NeurIPS draft:

**When Retrieval Quality Decouples from Faithfulness: A Pre-Registered Audit
of RAG Evaluation**

This directory blends the audit framing from `claudeneuroipspaper` with the
safer under-identification framing from `neuripsnewpaper`, and adds the
completed Fix 3 human calibration.

Build:

```bash
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

Supplement:

```bash
pdflatex supplement
```

The source-of-truth evidence remains in `results/revision/`, `data/revision/`,
`experiments/`, and `docs/revision/`. Public artifact links are intentionally
anonymized in the submission draft.
