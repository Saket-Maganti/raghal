# Reproducing ControlledRAG Results

This document explains how to verify the frozen analysis tables and
human-evaluation results in the anonymized artifact. The default path is
lightweight: it reads CSV files already included in the repository and
does not rerun generation, retrieval, or model scoring.

## Environment Setup

Use Python 3.10 or newer.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

The default `requirements.txt` contains only analysis dependencies:
`numpy`, `pandas`, `scipy`, and `scikit-learn`.

## Minimal Verification Path

Run the complete lightweight verification:

```bash
bash run_all_analysis.sh
```

This command runs the human-evaluation checks and rebuilds the compact
analysis tables used by the paper from frozen CSVs. It should complete
in under two minutes on a laptop.

## Human-Evaluation Checks

Typical-row calibration:

```bash
python3 scripts/verify_human_eval.py
```

Expected values for `n=99`:

| Quantity | Value |
| --- | --- |
| raw agreement | 0.919 |
| Cohen's kappa | 0.774 |
| adjudicated distribution | 79 supported / 16 partially supported / 4 unsupported |
| Spearman correlations | 0.103 / 0.394 / 0.549 |

Targeted disagreement slice:

```bash
python3 scripts/analyze_human_disagreement_labels.py \
  --input human_eval_final/n100_disagreement/annotation_batch_disagreement_100.csv \
  --output results/revision/fix_03/disagreement_alignment_n100.csv
```

Expected values for `n=100`:

| Quantity | Value |
| --- | --- |
| raw agreement | 0.88 |
| Cohen's kappa | 0.721 |
| adjudicated distribution | 74 faithful / 26 hallucinated / 0 unclear |
| Spearman correlations | -0.156 / 0.446 / 0.384 |
| AUROC | 0.398 / 0.794 / 0.718 |

There is no pending-label state for the `n=100` slice.

## Frozen CSV Locations

- `human_eval_final/n99_calibration/`: final `n=99` annotation files and summaries
- `human_eval_final/n100_disagreement/`: final `n=100` targeted disagreement files and summaries
- `results/revision/context_conditioned_nli/`: context-conditioned NLI rescoring outputs
- `results/revision/fix_01/`: matched context-structure audit
- `results/revision/fix_03/`: scorer-fragility summaries
- `results/revision/fix_04/`: threshold-transfer results
- `results/revision/fix_06/`: cost-aware head-to-head summaries
- `source_tables/`: compact table inputs used by the paper

See `SOURCE_TRACE.md` and `CLAIMS_AUDIT.md` for claim-to-file mapping.

## Lightweight vs. Expensive Scripts

Lightweight scripts:

- `scripts/verify_human_eval.py`
- `scripts/analyze_human_disagreement_labels.py`
- `scripts/compute_standardized_scorer_fragility.py`
- `scripts/compute_matched_ccs_distribution.py`
- `scripts/compute_cost_headtohead_cis.py`
- `scripts/compute_nli_human_correlation.py`
- `run_all_analysis.sh`

Expensive scripts:

- `experiments/fix_*.py`
- `experiments/run_*.py`
- `scripts/kaggle_*.py`
- `scripts/kaggle_*.sh`

The expensive scripts can regenerate selected frozen CSVs, but they are
not needed for review-time verification. They require local model
runtime, embedding models, and substantially more wall-clock time.

## Hardware Assumptions

The lightweight path runs on a normal laptop CPU. No paid APIs are
required.

Full regeneration of model outputs is outside the default verification
path. It assumes a local model runtime or a free GPU environment,
depending on the specific experiment, and can take several hours.

## Troubleshooting

- If imports fail, confirm the virtual environment is active and rerun
  `pip install -r requirements.txt`.
- If a verification script cannot find an input CSV, run it from the
  repository root.
- If `run_all_analysis.sh` stops early, run the two human-evaluation
  commands above first; they are the required checks for the reported
  human-evaluation values.
- If you need the full experiment dependency set, install
  `requirements-full.txt` in a separate environment.
