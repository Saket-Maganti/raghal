# Source Trace (Top Level)

This file records the source artifacts for the ControlledRAG audit
pass. Every numerical claim in `papers/paper_neurips/main.tex` and
`papers/paper_neurips/supplement.tex` traces to one of the entries
below. The reviewer-facing copy under
`papers/paper_neurips/SOURCE_TRACE.md` is the authoritative version
that is shipped inside the supplement and the reviewer artifact.

## Existing core results

- Matched-context (Fix 1): `results/revision/fix_01/`
- Scaled audit (Fix 2): `results/revision/fix_02/`
- Metric fragility on 7,500 fixed Mistral generations (Fix 3):
  `results/revision/fix_03/table1_multimetric.csv`,
  `results/revision/fix_03/metric_correlations.csv`,
  `results/revision/fix_03/standardized_scorer_fragility.csv`.
- Context-conditioned NLI rescoring (Fix 3 follow-up):
  `results/revision/context_conditioned_nli/per_query_n600.csv`,
  `results/revision/context_conditioned_nli/contrasts_n600.csv`,
  `results/revision/context_conditioned_nli/n99_with_ctx_scores.csv`,
  `results/revision/context_conditioned_nli/n99_alignment_spearmans.csv`.
- Threshold transfer (Fix 4): `results/revision/fix_04/`.
- Coherence vs noise (Fix 5): `results/revision/fix_05/`.
- Cost-aware head-to-head (Fix 6 + Fix 11):
  `data/revision/fix_06/per_query_compact.csv`,
  `results/revision/fix_06/h2h_summary.csv`,
  `results/revision/fix_06/h2h_summary_with_ci.csv`,
  `results/revision/fix_11/raptor_full_table.csv`.

## Human-evaluation final files (single source of truth)

The reviewer-facing artifact ships the **completed** human-eval files
under `human_eval_final/`. Old per-fix locations under
`data/revision/fix_03/` and `results/human_disagreement_expansion/`
are intermediate / staging; the final values used by the paper come
from `human_eval_final/`.

### n=99 typical-row calibration

- `human_eval_final/n99_calibration/human_eval_adjudicated.csv`
  (combined: rater_a_label, rater_b_label, adjudicated_label,
  adjudication_notes; 99 rows)
- `human_eval_final/n99_calibration/human_eval_n99_with_context.csv`
  (per-row file with retrieved-context column; 99 rows)
- `human_eval_final/n99_calibration/human_eval_summary.csv`
  (n=99, raw_agreement=0.919192, cohen_kappa=0.773779)
- `human_eval_final/n99_calibration/human_eval_label_distribution.csv`
  (79 supported / 16 partially_supported / 4 unsupported)
- `human_eval_final/n99_calibration/human_eval_correlations.csv`
  (auto_deberta Spearman 0.103023; auto_second_nli 0.393969;
  auto_ragas 0.548699)
- `human_eval_final/n99_calibration/bootstrap_correlation_cis.csv`
  (n=99 paired-bootstrap CIs and the 7,500-row metric-pair CIs)
- `human_eval_final/n99_calibration/human_eval_verification.csv`
  (verification trace from `scripts/verify_human_eval.py`)

### n=100 targeted scorer-disagreement evaluation (completed)

- `human_eval_final/n100_disagreement/annotation_batch_disagreement_100.csv`
  (merged batch with scorer scores, rater 1, rater 2, adjudicated)
- `human_eval_final/n100_disagreement/human_eval_rater1.csv`
  (rater 1: 100/100)
- `human_eval_final/n100_disagreement/human_eval_rater2.csv`
  (rater 2: 100/100)
- `human_eval_final/n100_disagreement/human_eval_adjudicated.csv`
  (rater 1 label, rater 2 label, adjudicated label, adjudication notes)
- `human_eval_final/n100_disagreement/human_eval_adjudication_template.csv`
  (reconciliation template used during adjudication)
- `human_eval_final/n100_disagreement/human_disagreement_summary.csv`
  (100 / 100 / 100 / 12 disagreements / 74 faithful / 26 hallucinated /
  0 unclear)
- `human_eval_final/n100_disagreement/human_disagreement_label_distribution.csv`
  (rater 1, rater 2, and adjudicated distributions)
- `human_eval_final/n100_disagreement/human_disagreement_agreement.csv`
  (raw_agreement=0.88, cohen_kappa=0.7209)
- `human_eval_final/n100_disagreement/human_disagreement_correlations.csv`
  (DeBERTa Spearman −0.156045; second_NLI 0.446432; RAGAS_style 0.384277)
- `human_eval_final/n100_disagreement/human_disagreement_auroc_auprc.csv`
  (AUROC 0.398/0.794/0.718; AUPRC 0.765/0.929/0.859)
- `human_eval_final/n100_disagreement/human_disagreement_bootstrap_cis.csv`
  (1000-resample bootstrap CIs)

The `human_eval_final/n100_disagreement/annotation_batch_disagreement_PREANNOTATION.csv`
file is a draft/intermediate artifact retained for documentation. It
is **not** used for any paper claim.

### Verification scripts

- `scripts/verify_human_eval.py` — regenerates n=99 numbers; primary
  copy under `human_eval_final/scripts/verify_human_eval.py`.
- `scripts/analyze_human_disagreement_labels.py` — regenerates n=100
  numbers; primary copy under
  `human_eval_final/scripts/analyze_human_disagreement_labels.py`.
- `scripts/run_context_conditioned_nli_scoring.py` — context-conditioned
  NLI rescoring on the n=600 subset.
- `scripts/prepare_human_disagreement_eval.py` — batch construction.

## Follow-up audit fixes (Fix 12–15)

### Fix 12 - answer-span/control diagnostic

- Script: `experiments/fix_12_answer_span_diagnostic.py`
- Inputs:
  - `data/revision/fix_01/per_query.csv`
  - `data/revision/fix_01/matched_pairs.csv`
- Generated data:
  - `data/revision/fix_12/span_control_rows.csv`
- Results:
  - `results/revision/fix_12/span_control_summary.csv`
  - `results/revision/fix_12/span_control_models.csv`
  - `results/revision/fix_12/span_control_report.md`
- Paper table:
  - `source_tables/span_control_summary.csv`

### Fix 13 - stronger retriever sanity check

- Script: `experiments/fix_13_retriever_sanity.py`
- Inputs:
  - `data/revision/fix_01/per_query.csv`
  - `data/revision/fix_01/matched_pairs.csv`
  - `data/revision/fix_12/span_control_rows.csv`
  - `results/multi_retriever/paradox_by_embedder.csv`
- Generated data:
  - `data/revision/fix_13/matched_context_reencoded.csv`
  - `data/revision/fix_13/scaled_paradox_input_copy.csv`
- Results:
  - `results/revision/fix_13/retriever_sanity_summary.csv`
  - `results/revision/fix_13/retriever_sanity_report.md`
- Paper table:
  - `source_tables/retriever_sanity_summary.csv`

### Fix 14 - second-generator metric-fragility replication

- Script: `experiments/fix_14_second_generator_metric_fragility.py`
- Inputs:
  - `data/revision/fix_02/per_query.csv`
- Runtime:
  - local Ollama generator `qwen2.5`
  - local DeBERTa NLI scorer
  - local `roberta-large-mnli` scorer
  - local RAGAS-style judge through Ollama `mistral`
- Generated data:
  - `data/revision/fix_14/second_generator_sample_manifest.csv`
  - `data/revision/fix_14/second_generator_per_query.csv`
- Results:
  - `results/revision/fix_14/second_generator_metrics.csv`
  - `results/revision/fix_14/second_generator_correlations.csv`
  - `results/revision/fix_14/second_generator_report.md`
- Paper table:
  - `source_tables/second_generator_metrics.csv`

### Fix 15 - long-form/synthesis stress test

- Script: `experiments/fix_15_longform_stress.py`
- Inputs:
  - `results/longform/per_query.csv`
  - `results/longform/summary.csv`
  - `results/longform/paradox_longform.csv`
- Generated data:
  - `data/revision/fix_15/longform_stress_per_query.csv`
- Results:
  - `results/revision/fix_15/longform_stress_summary.csv`
  - `results/revision/fix_15/longform_stress_report.md`
- Paper table:
  - `source_tables/longform_stress_summary.csv`
