# ControlledRAG Reproducibility Artifact

This repository contains the anonymized reproducibility artifact for
ControlledRAG, a seven-axis reporting standard for RAG faithfulness
evaluation. The artifact focuses on verifying reported tables and
human-evaluation results. It does not include author-identifying links,
public demos, or internal revision history.

## Repository contents

- `scripts/`: analysis and verification scripts
- `human_eval_final/`: final human-evaluation files
- `results/`: frozen result tables used by the paper
- `data/`: small/frozen data artifacts required by scripts
- `source_tables/`: source CSVs for paper claims
- `run_all_analysis.sh`: lightweight verification entry point
- `README_REPRODUCE.md`: detailed reproduction instructions

## Quick start

    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
    bash run_all_analysis.sh

## Verify human evaluation

    python3 scripts/verify_human_eval.py
    python3 scripts/analyze_human_disagreement_labels.py \
        --input human_eval_final/n100_disagreement/annotation_batch_disagreement_100.csv \
        --output results/revision/fix_03/disagreement_alignment_n100.csv

Expected values:

Typical-row calibration (`n=99`):
- raw agreement: 0.919
- Cohen's kappa: 0.774
- adjudicated distribution: 79/16/4
- Spearman correlations: 0.103/0.394/0.549

Targeted disagreement slice (`n=100`):
- raw agreement: 0.88
- Cohen's kappa: 0.721
- adjudicated distribution: 74/26/0
- Spearman correlations: -0.156/0.446/0.384
- AUROC: 0.398/0.794/0.718

## Reproducing paper tables

See `README_REPRODUCE.md`.

## Notes

- Generation outputs are frozen and are not rerun by default.
- Heavy model jobs are separated from lightweight verification.
- No paid APIs are required for the verification path.
- This repository is anonymized for double-blind review.

## License

License information will be added for the public release.
