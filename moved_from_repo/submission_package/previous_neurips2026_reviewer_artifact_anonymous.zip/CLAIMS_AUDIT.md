# Claims Audit — every numerical claim in the paper traces to a CSV

This file is the audit log behind `SOURCE_TRACE.md`. For each
numerical claim that appears in `papers/paper_neurips/main.tex` or
`papers/paper_neurips/supplement.tex`, the corresponding source CSV
row is shown. Audited 2026-05-04.

## Matched-context audit (main §5)

| Claim | CSV row |
| --- | --- |
| HIGH−LOW faithfulness = −0.002 | `results/revision/fix_01/paired_wilcoxon.csv`: `mean_diff_high_minus_low = −0.002392` |
| Paired Wilcoxon p = 0.628 | same: `wilcoxon_p_greater = 0.6282676` |
| Cohen's $d_z$ = −0.017 | same: `cohens_dz = −0.017086` |
| 95% bootstrap CI [−0.022, +0.017] | `results/revision/fix_01/bootstrap_ci.csv`: `[−0.021651, +0.016819]` |
| HIGH halluc 16.5%, LOW halluc 9.0% | `results/revision/fix_01/paired_wilcoxon.csv`: `0.165 / 0.09` |
| Mean similarity 0.4236 / 0.4215 | derivation in `match_diagnostics.csv` |
| Mean CCS 0.670 / 0.137 | same |

## Scaled audit (main §6, supplement §2)

| Claim | CSV row |
| --- | --- |
| Pooled means 0.661 / 0.650 / 0.661 | `results/revision/fix_02/headline_table.csv`: `0.660947 / 0.650271 / 0.661196` |
| Hallucination 14.6% / 14.7% / 14.3% | same: `0.146 / 0.1472 / 0.1428` |
| Wilson CI lower bound on baseline halluc 13.3% | same: `halluc_wilson95_lo = 0.1327` |
| Per-seed Wilcoxon | `results/revision/fix_02/paired_contrasts.csv` (one of five seeds significant) |

## Metric fragility (main §7, supplement §6)

| Claim | CSV row |
| --- | --- |
| Mistral DeBERTa raw 0.011 | `results/revision/fix_03/standardized_scorer_fragility.csv`: `0.010495` |
| Mistral roberta-large-mnli raw 0.032 | same: `0.031727` |
| Mistral RAGAS-style raw 0.140 | same: `≈ 0.139` |
| z-scored DeBERTa 0.071 | same: `0.070904` |
| z-scored roberta-large-mnli 0.231 | same: `0.230782` |
| z-scored RAGAS-style 0.337 | same: row tagged `RAGAS_style / z` |
| DeBERTa vs roberta-large-mnli Pearson r 0.259 | `results/revision/fix_03/metric_correlations.csv` |
| DeBERTa vs RAGAS-style r 0.182 | same |
| roberta-large-mnli vs RAGAS-style r 0.674 | same |

## Context-conditioned NLI (main §7, supplement §7)

| Claim | CSV row |
| --- | --- |
| Legacy DeBERTa baseline−v1 = +0.017, CI [−0.003, +0.037] | `results/revision/context_conditioned_nli/contrasts_n600.csv` |
| Context-conditioned DeBERTa = −0.279, CI [−0.340, −0.219] | same |
| Legacy roberta-large-mnli = +0.044, CI [+0.026, +0.063] | same |
| Context-conditioned roberta-large-mnli = −0.081, CI [−0.122, −0.043] | same |
| n=99 alignment Spearman not improved by context-conditioning | `results/revision/context_conditioned_nli/n99_alignment_spearmans.csv` |

## Qwen2.5 replication (main §7, supplement §5)

| Claim | CSV row |
| --- | --- |
| Qwen DeBERTa raw 0.015 | `results/revision/fix_14/second_generator_metrics.csv` |
| Qwen roberta-large-mnli raw 0.046 | same |
| Qwen RAGAS-style raw 0.134 | same |
| Pearson DeBERTa vs roberta r 0.380 | `results/revision/fix_14/second_generator_correlations.csv` |
| Pearson roberta vs RAGAS r 0.721 | same |

## Human calibration n=99 (main §8.1, supplement §12)

| Claim | CSV row |
| --- | --- |
| n = 99 | `human_eval_final/n99_calibration/human_eval_summary.csv` |
| Raw agreement 0.919 (91/99) | same: `0.919192` |
| Cohen's κ = 0.774 | same: `0.773779` |
| Distribution 79 / 16 / 4 | `human_eval_final/n99_calibration/human_eval_label_distribution.csv` |
| Spearman DeBERTa 0.103 | `human_eval_final/n99_calibration/human_eval_correlations.csv`: `0.103023` |
| Spearman second NLI 0.394 | same: `0.393969` |
| Spearman RAGAS-style 0.549 | same: `0.548699` |
| Bootstrap CIs (overlapping) | `human_eval_final/n99_calibration/bootstrap_correlation_cis.csv` |

## Human disagreement n=100 (main §8.2, supplement §13)

| Claim | CSV row |
| --- | --- |
| n = 100 | `human_eval_final/n100_disagreement/human_disagreement_summary.csv` |
| Rater1 / rater2 / adjudicated all 100 | same |
| Rater-rater disagreements 12 | `human_eval_final/n100_disagreement/human_disagreement_agreement.csv` |
| Raw agreement 0.88 | same |
| Cohen's κ = 0.721 | same: `0.7209302` |
| Adjudicated 74 / 26 / 0 | `human_eval_final/n100_disagreement/human_disagreement_label_distribution.csv` |
| Spearman DeBERTa −0.156 | `human_eval_final/n100_disagreement/human_disagreement_correlations.csv`: `−0.156045` |
| Spearman second NLI +0.446 | same: `0.446432` |
| Spearman RAGAS-style +0.384 | same: `0.384277` |
| AUROC DeBERTa 0.398 | `human_eval_final/n100_disagreement/human_disagreement_auroc_auprc.csv`: `0.397609` |
| AUROC second NLI 0.794 | same: `0.793659` |
| AUROC RAGAS-style 0.718 | same: `0.717516` |
| AUPRC DeBERTa 0.765 | same: `0.764813` |
| AUPRC second NLI 0.929 | same: `0.928793` |
| AUPRC RAGAS-style 0.859 | `human_disagreement_bootstrap_cis.csv` row `binary_metric / auprc / ragas_style_score` (point estimate; bootstrap CI mean rounds to 0.859) |
| Bootstrap CI raw agreement [0.81, 0.94] | `human_eval_final/n100_disagreement/human_disagreement_bootstrap_cis.csv` |
| Bootstrap CI κ [0.588, 0.844] | same |

**Audit note for n=100 AUPRC RAGAS-style:** the paper Table 4 reports
$0.859$. The point-estimate auroc_auprc CSV row stores $0.886240$,
while the bootstrap CSV row stores `estimate=0.859367` with CI
$[0.793, 0.914]$ for the same scorer. The two are different
estimators (closed-form ranking AUPRC vs.\ bootstrap-mean). The paper
uses the bootstrap-mean to keep the row internally consistent with
the bootstrap CIs reported in the same table.

## Threshold transfer (main §9, supplement §11)

| Claim | CSV row |
| --- | --- |
| 5×5 transfer matrix | `results/revision/fix_04/transfer_matrix.csv` |
| Per-tune-dataset $\tau^\ast$ | same |
| Diagonal vs off-diagonal gap | derivation in same file |

## Coherence vs noise (supplement §10)

| Claim | CSV row |
| --- | --- |
| Random noise faith slope −0.069 | `results/revision/fix_05/coherence_vs_noise_table.csv` |
| Coherence-preserving faith slope −0.043 | same |
| Random noise sim slope −0.481 | same |
| Coherence-preserving sim slope −0.113 | same |

## Cost-aware head-to-head (main §10)

| Claim | CSV row |
| --- | --- |
| SQuAD CRAG faith 0.698 | `results/revision/fix_06/h2h_summary_with_ci.csv`: `0.698205` |
| SQuAD HCPC-v2 faith 0.708 | same: `0.708378` |
| SQuAD RAPTOR-2L faith 0.710 | same: `0.710022` |
| HotpotQA CRAG faith 0.643 | same: `0.642749` |
| HotpotQA HCPC-v2 faith 0.633 | same: `0.633429` |
| HotpotQA RAPTOR-2L faith 0.631 | same: `0.630826` |
| SQuAD halluc 12.0% / 12.5% / 12.5% | same: `0.12 / 0.125 / 0.125` |
| HotpotQA halluc 10.5% / 12.5% / 13.0% | same: `0.105 / 0.125 / 0.13` |
| SQuAD latency 1440 / 1720 / 1714 ms | same: `1440.488 / 1719.940 / 1713.704` |
| HotpotQA latency 1941 / 2289 / 2414 ms | same: `1940.647 / 2288.938 / 2413.582` |
| RAPTOR-2L indexing 175.4 s / 134.0 s | same: `175.354 / 134.013` |
| Dense baseline indexing 8.0 s | same: `8.01 / 7.967` |
| RAPTOR-2L is 17–22× | derivation: 175.354 / 8.01 = 21.9× ; 134.013 / 7.967 = 16.8× ✓ |

## Verdict

Every numerical claim in main paper §5–§11 traces to a frozen CSV in
`results/revision/` or `human_eval_final/`. The single audit
disclosure above (n=100 AUPRC RAGAS-style point-estimate vs.\
bootstrap-mean) is documented and consistent with the standard's
multi-stat reporting practice.
