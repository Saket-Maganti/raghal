#!/usr/bin/env bash
# run_all_analysis.sh
# Re-derives every analysis table the main paper and supplement use,
# starting from the frozen per-query CSVs in `results/revision/`,
# `results/revision/context_conditioned_nli/`, and `human_eval_final/`.
# Designed to run on any laptop in under two minutes.

set -euo pipefail

cd "$(dirname "$0")"

echo "[1/6] Verifying n=99 typical-row calibration..."
python3 scripts/verify_human_eval.py

echo "[2/6] Verifying n=100 targeted scorer-disagreement evaluation..."
mkdir -p results/revision/fix_03
python3 scripts/analyze_human_disagreement_labels.py \
    --input human_eval_final/n100_disagreement/annotation_batch_disagreement_100.csv \
    --output results/revision/fix_03/disagreement_alignment_n100.csv

echo "[3/6] Recomputing standardized scorer-fragility contrasts..."
if [ -x scripts/compute_standardized_scorer_fragility.py ] || [ -f scripts/compute_standardized_scorer_fragility.py ]; then
  python3 scripts/compute_standardized_scorer_fragility.py || true
else
  echo "  (script not present; skipping)"
fi

echo "[4/6] Recomputing matched HIGH/LOW CCS distribution..."
if [ -f scripts/compute_matched_ccs_distribution.py ]; then
  python3 scripts/compute_matched_ccs_distribution.py || true
else
  echo "  (script not present; skipping)"
fi

echo "[5/6] Recomputing cost-aware head-to-head CIs..."
if [ -f scripts/compute_cost_headtohead_cis.py ]; then
  python3 scripts/compute_cost_headtohead_cis.py || true
else
  echo "  (script not present; skipping)"
fi

echo "[6/6] Recomputing NLI-vs-human Spearman on n=99..."
if [ -f scripts/compute_nli_human_correlation.py ]; then
  python3 scripts/compute_nli_human_correlation.py || true
else
  echo "  (script not present; skipping)"
fi

echo ""
echo "Done. Verify outputs against:"
echo "  - human_eval_final/n99_calibration/human_eval_summary.csv"
echo "  - human_eval_final/n100_disagreement/human_disagreement_summary.csv"
echo "  - results/revision/fix_03/standardized_scorer_fragility.csv"
echo "  - results/revision/fix_06/h2h_summary_with_ci.csv"
