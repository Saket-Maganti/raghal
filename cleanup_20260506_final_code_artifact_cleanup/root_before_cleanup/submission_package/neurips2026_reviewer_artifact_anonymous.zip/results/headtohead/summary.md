# Head-to-head: HCPC vs Self-RAG vs CRAG

## Aggregated metrics

| dataset   | condition   |   n |   faith |   halluc |    sim |   latency |
|:----------|:------------|----:|--------:|---------:|-------:|----------:|
| hotpotqa  | baseline    |  30 |  0.6091 |   0.1667 | 0.552  |    2.128  |
| hotpotqa  | crag        |  30 |  0.6314 |   0.2333 | 0.6051 |    1.4163 |
| hotpotqa  | hcpc_v1     |  30 |  0.6498 |   0.1667 | 0.5699 |    1.633  |
| hotpotqa  | hcpc_v2     |  30 |  0.6073 |   0.2333 | 0.5519 |    1.977  |
| hotpotqa  | selfrag     |  30 |  0.5509 |   0.4333 | 0.552  |    4.541  |
| pubmedqa  | baseline    |  30 |  0.6091 |   0.1    | 0.5166 |    4.3717 |
| pubmedqa  | crag        |  30 |  0.5862 |   0.3333 | 0.7206 |    2.8493 |
| pubmedqa  | hcpc_v1     |  30 |  0.5656 |   0.2333 | 0.5471 |    3.0503 |
| pubmedqa  | hcpc_v2     |  30 |  0.5802 |   0.1667 | 0.5168 |    3.811  |
| squad     | baseline    |  30 |  0.7841 |   0.0333 | 0.6154 |    4.838  |
| squad     | crag        |  30 |  0.7872 |   0.0333 | 0.6264 |    1.2327 |
| squad     | hcpc_v1     |  30 |  0.7175 |   0.0333 | 0.6172 |    1.3657 |
| squad     | hcpc_v2     |  30 |  0.7972 |   0      | 0.6152 |    1.2527 |
| squad     | selfrag     |  22 |  0.5504 |   0.4545 | 0.604  |    5.6686 |

Comparison conventions:
- `baseline` and `hcpc_*` and `crag` use Ollama-served Mistral-7B.
- `selfrag` uses the published `selfrag/selfrag_llama2_7b` checkpoint.
- All conditions use the same retrieval corpus and top-k=3.
- CRAG is a reimplementation; web search is disabled by default.